## Getting Started

Welcome to the VS Code Java world. Here is a guideline to help you get started to write Java code in Visual Studio Code.

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

Meanwhile, the compiled output files will be generated in the `bin` folder by default.

> If you want to customize the folder structure, open `.vscode/settings.json` and update the related settings there.

Some people who may have a different version of the extensions and may or may not see the "src" and "bin" and "lib" folders. It's OK as long as you are able to right-click and create new Java packages, right-click and create new Java classes, and run your code.

For this GitHub repo, you will need to look inside the src folder to see all the code that we completed during class.
