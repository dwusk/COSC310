package chap8.users;

public abstract class Employee extends User {

    public Employee(String name, String id, String username, String password) {
        super(name, id, username, password);
    }

}
